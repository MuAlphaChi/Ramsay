var express = require('express'); 
var fs = require('fs');
var http = require('http'); 
var app = express(); 
var request = require('request');
var responding = true;
var logging = true;
var interactionID = 0;
var Variables = [];
var ConundrumsWaitingID = [];
var ConundrumsWaitingSolution = [];
//initVariables();
app.set('port', process.env.PORT || 3000); 
app.use(express.bodyParser()); 
app.use(app.router);
app.get('/', verificationHandler);
app.post('/',handleMessage);
logText("---------------------------------- Program Restarted ----------------------------------");

String.prototype.contains = function (t) {
    if (t.constructor == Array) {
        for (var i = 0; i < t.length; i++) {
            if (t[i].constructor == RegExp) {
                if (this.replace(t[i], "") != this) {
                    return true;
                }
            } else {
                if (this.replace(new RegExp('\\b(' + t[i] + ')\\b'), "") != this) {
                    return true;
                }
            }
        }
        return false;
    } else if (t.constructor == RegExp) {
        if (this.replace(t, "") != this) {
            return true;
        }
    } else {
        if (this.replace(new RegExp('\\b(' + t + ')\\b'), "") != this) {
            return true;
        }
        return false;
    }
}

String.prototype.beginsWith = function(str) {
    for (var i = 0; i < str.length; i++) {
        if (this.charAt(i) != str.charAt(i)) {
            return false;
        }
    }
    return true;
}

String.prototype.titleize = function() {
    var strArray = this.split(' ');
    for (var i = 0; i < strArray.length; i++) {
       strArray[i] = strArray[i].charAt(0).toUpperCase() + strArray[i].slice(1);
    }
    return strArray.join(' ');
}

function verificationHandler(req, res) {
    logText(req);
    if (req.query['hub.verify_token'] === 'P31415I1707M') {
        res.send(req.query['hub.challenge']);
    }
    res.send('Error, wrong validation token!');
}

function wikiQuery(query, id, str) {
    query = query.titleize();
    logText("Query made to Wikipedia API");
    logText("Query: " + query);
    var url = `https://en.wikipedia.org/w/api.php?action=opensearch&search="` + query + `"&redirects=resolve&format=json`;
    request(url, function (err, response, body) {
        if(err){
            logText("Unable to Connect to Wikipedia API");
            sendMessage(id, "I don't know. Why don't you check yourself?")
        } else {
            body = JSON.parse(body);
            var summary = body[2][0]
            for (var i = 0; i < body[1].length; i++) {
                if (body[1][i].toLowerCase() == query) {
                    summary = body[2][i]
                }
            }
            var responces = [];
            if (summary == undefined || summary == "") {
                summary = "";
                responces = ["I can't be bothered to answer that, just ask Google.", "Who knows? The internet probably.", "I don't know, ask Google.",];
                for (var i = 0; i < responces.length; i++) {
                    responces[i] = responces[i] + " (link: https://www.google.co.uk/#q=" + str.split(" ").join('+') + " ) ";
                }
            } else {
                responces = ["According to Wikipedia: ", ""];
            }
            var i = Math.floor(Math.random() * responces.length);
            sendMessage(id, responces[i] + summary);
        }
    });
}

function logText(text) {
    if (logging) {
        var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"
                    ,"Oct", "Nov", "Dec"];
        var d = new Date;
        d.setMonth(d.getMonth() + 1);
        d.setHours(d.getHours() + 1);
        var date = d.getDate() + "." + d.getMonth() + "." + d.getFullYear();
        var time = ((("" + d.getHours()).length == 2)? "" : "0" ) + (d.getHours()) + ":" 
                 + ((("" + d.getMinutes()).length == 2)? "" : "0" ) + d.getMinutes() + ":" 
                 + ((("" + d.getSeconds()).length == 2)? "" : "0" ) + d.getSeconds();
        try {
            fs.mkdirSync('logs/' + d.getFullYear());
        } catch (err) {
        }
        try {
            fs.mkdirSync('logs/' + d.getFullYear() + '/' 
                        + d.getMonth() + " " 
                        + months[d.getMonth() - 1]);
        } catch (err) {
        }
        fs.appendFileSync('logs/' + d.getFullYear() + '/' 
                        + d.getMonth() + " " 
                        + months[d.getMonth() - 1] 
                        +'/log (' + date + ').txt'
                        , "[" + time + "] " + text + "\n");
        console.log("[" + time + "] " + text);
    }
}

Number.prototype.noExponents= function() {
    var data= String(this).split(/[eE]/);
    if(data.length== 1) return data[0]; 

    var  z= '', sign= this<0? '-':'',
    str= data[0].replace('.', ''),
    mag= Number(data[1])+ 1;

    if(mag<0){
        z= sign + '0.';
        while(mag++) z += '0';
        return z + str.replace(/^\-/,'');
    }
    mag -= str.length;  
    while(mag--) z += '0';
    return str + z;
}

function getRandomFromFile(s) {
    var responces = (fs.readFileSync('responces/' + s + '.txt', 'utf8')).split("\n");
    do {
        var i = Math.floor(Math.random() * responces.length);
    }
    while (responces[i] == "");
    return responces[i];
}

function handleMessage(req, res) {
  var messaging_events = req.body.entry[0].messaging;
  for (var i = 0; i < messaging_events.length; i++) {
    event = req.body.entry[0].messaging[i];
    var sender = event.sender.id;
    if (event.message && event.message.text) {
        var text = event.message.text;
        var d = new Date;
        interactionID++;
        logText("------------------------------------");        
        logText("New Interaction with " + sender);
        logText("Interaction ID: " + interactionID);
        logText("Message recieved from " + sender);
        logText("Message: " + text.replace(/(\r\n)|(\r)|(\n)/, " "));
        var userBanned = false;
        //var bannedUsers = fs.
        //for (var i = 0;)
        say(sender, text);
    }
  }
  res.end('received!');
}

http.createServer(app).listen(app.get('port'), function() {
  logText('Express server listening on port ' + app.get('port'));
});

function createDataEntry(id, type, string) {
    fs.writeFileSync("data/" + type + "/" + id, string);
}

function getDataEntry(id, type) {
    if (fs.existsSync("data/" + type + "/" + id)) {
        return fs.readFileSync("data/" + type + "/" + id, 'utf8');
    } else {
        return type;
    }
}

function sendMessage(id,str) {
    if (str != "") {
        var url = "https://graph.facebook.com/v2.6/me/messages?access_token=EAALfe7rgIZBYBAJARRMnNTHu8iYEJWnCBIbvwqZAdISZAztvXz4yV5RsUUpQW8GiZAk7JM4kjyKjSZBbnNvX6JNesOPb361wU16cc6KA5yneQq3B6ZC8nCPIqS5306qLZAB5bWwtg8hZBjG0KFuaGDAc7ZBaBM7vWnH4nR43SP3MlowZDZD";
        var options = {
            uri: url,
            method: 'POST',
            json: {
                "recipient": {
                    "id": id
                },
                "message": {
                    "text": str
                }
            }
        };
        request(options, function(error, response, body) {
            if (error) {
                    logText(error.message);
            }
        });
        logText("Message sent to " + id);
        logText("Message: " + str);
    }
}

// BRAIN

String.prototype.isInterrogative = function () {
    var interrogativeWords = ["why", "which", "what", "whose", "who", "whom", "where"
    , "whence", "when", "how", "whether", "are", "do", "does", "can", "did", "have"
    , "should", "could", "would", "is"];
    for (var i in interrogativeWords) {
        if (this.beginsWith(interrogativeWords[i] + " ")) {
            return true;
        }
    }
    return false;
}


function gamma(z) {
    var g = 7;
    var C = [0.99999999999980993, 676.5203681218851, -1259.1392167224028,771.32342877765313
    , -176.61502916214059, 12.507343278686905, -0.13857109526572012
    , 9.9843695780195716e-6, 1.5056327351493116e-7];
    if (z < 0.5) return Math.PI / (Math.sin(Math.PI * z) * gamma(1 - z));
    else {
        z -= 1;
        var x = C[0];
        for (var i = 1; i < g + 2; i++)
        x += C[i] / (z + i);
        var t = z + g + 0.5;
        return Math.sqrt(2 * Math.PI) * Math.pow(t, (z + 0.5)) * Math.exp(-t) * x;
    }
}

Number.prototype.fact = function() {
    var number = this;
    if (number % 1 != 0 || number<0){
        return gamma(number + 1);
    }
    else {
        if(number == 0) {
           return 1;
        }
        for(var i = number; --i; ) {
           number *= i;
        }
        return number;
    }
}

function QFormula(a, b, c) {
    var discrim = Math.pow(b, 2) - 4*a*c;
    if (discrim < 0) {
        return "-";
    }
    var denom = 2*a;
    return [Math.round((((-1*b) - Math.sqrt(discrim))/denom)*10000)/10000
            ,Math.round((((-1*b) + Math.sqrt(discrim))/denom)*10000)/10000];
}

String.prototype.solveQuadratic = function() {
    var num = ["","",""];
    var index = 0;
    var numOfX = 0;
    var quadratic = this.split("");
    for (var i = 0; i < quadratic.length; i++) {
        if (quadratic[i] != "x") {
            num[index] += quadratic[i];
        } else {
            index++;
            numOfX++;
        }
    }
    if (numOfX == 1) {
        num[2] = num[1];
        num[1] = "0";
    } if (numOfX == 2 && num[2] == "") { num[2] = "0"; }
    for (var i = 0; i < num.length; i++) {
        if (num[i] == "") { num[i] = "1"; }
    }
    
    return QFormula(parseInt(num[0]), parseInt(num[1]), parseInt(num[2]));
}

String.prototype.calcFromStringOneNum = function () {
    var arr = this.split("");
    var a = "";
    var sign = "";
    for (var i = 0; i < arr.length; i++) {
        if (arr[i].match(/[-0-9.]/)) {
            a += arr[i];
        } else {
            sign += arr[i];
        }
    }
    switch (sign) {
        case "factorial":
        case "!":
            return Math.round(parseFloat(a).fact()*10000)/10000;
        case "squared":
            return Math.round((Math.pow(parseFloat(a), 2))*10000)/10000;
        case "cubed":
            return Math.round((Math.pow(parseFloat(a), 3))*10000)/10000;
        case "sin":
        case "sine":
            return Math.round((Math.sin(parseFloat(a)*(Math.PI/180)))*10000)/10000;
        case "cos":
        case "cosine":
            return Math.round((Math.cos(parseFloat(a)*(Math.PI/180)))*10000)/10000;
        case "tan":
        case "tangent":
            return Math.round((Math.tan(parseFloat(a)*(Math.PI/180)))*10000)/10000;
        case "sinc":
        case "sinec":
            return Math.round((Math.sin(parseFloat(a)))*10000)/10000;
        case "cosc":
        case "cosinec":
            return Math.round((Math.cos(parseFloat(a)))*10000)/10000;
        case "tanc":
        case "tangentc":
            return Math.round((Math.tan(parseFloat(a)))*10000)/10000;
        case "sqrt":
        case "squareroot":
        case "thesquarerootof":
            if (parseInt(a) < 0) {
                return "imaginary";
            }
            return Math.round(Math.sqrt(parseFloat(a))*10000)/10000;
        default:
            return "6? No? Sorry I'm not sure"
    }
}

String.prototype.getMultiplierFromTime = function () {
    var word = "" + this;
    switch (word) {
        case "sec":
        case "secs":
        case "second":
        case "seconds":
            return 1000;
        case "min":
        case "mins":
        case "minute":
        case "minutes":
            return 60000;
        case "hour":
        case "hours":
            return 360000;
        case "day":
        case "days":
            return 86400000;
        default:
            return 1;
    }
}

String.prototype.calcFromStringTwoNum = function () {
    var arr = this.split("");
    var aOver = false;
    var a = "";
    var b = "";
    var sign = "";
    var subSign = true;
    for (var i = 0; i < arr.length; i++) {
        if (arr[i] == "-" && subSign) {
            if (aOver) {
                b += arr[i];
            } else {
                a += arr[i];
            }
            subSign = false;
        } else if (arr[i].match(/[0-9.]/)) {
            if (aOver) {
                b += arr[i];
            } else {
                a += arr[i];
            }
            subSign = false;
        } else {
            sign += arr[i];
            aOver = true;
            subSign = true;
        }
    }
    switch (sign) {
        case "*":
        case "x":
        case "multipliedby":
        case "times":
            return Math.round((parseFloat(a) * parseFloat(b))*10000)/10000;
        case "+":
        case "add":
        case "plus":
            return Math.round((parseFloat(a) + parseFloat(b))*10000)/10000;
        case "-":
        case "subtract":
        case "minus":
            return Math.round((parseFloat(a) - parseFloat(b))*10000)/10000;
        case "/":
        case "dividedby":
            if (b == "0") {
                return "indeterminate"
            } else {
                return Math.round((parseFloat(a) / parseFloat(b))*10000)/10000;
            }
        case "tothepowerof":
        case "^":
        case "raisedtothe":
            return Math.round((Math.pow(parseFloat(a), parseFloat(b)))*10000)/10000;
        default:
            return "6? No? Sorry I'm not sure"
    }
}

function say(id, str) {
    if (str.beginsWith(">>> ")) {
        if (id == "1308167729292227") {
            admin(str, id);
        } else {
            sendMessage(id, "You do not have permission for this command");
        }
    } else if (responding) {
        str = simFilter(str);
        if (ConundrumsWaitingID.join(" ").contains(id)) {
            var index = 0;
            for (var i = 0; i < ConundrumsWaitingID.length; i++) {
                if (ConundrumsWaitingID[i] == id) {
                    index = i;
                }
            }
            var responces = [];
            if (str == ConundrumsWaitingSolution[index].toLowerCase() 
            || fs.readFileSync("responces/conundrums.txt", 'utf8').toLowerCase().contains(str)) {
                responces = ["Wow, you actually got it correct.", "That's correct, well done.", "That's correct."];
            } else {
                responces = [`Incorrect, just as I expected. The answer is ${ConundrumsWaitingSolution[index]}.`
                    , `I'm afraid that's wrong. The answer is ${ConundrumsWaitingSolution[index]}.`
                    , `That's incorrect. The answer is ${ConundrumsWaitingSolution[index]}.`];
            }
            ConundrumsWaitingID[index] = "";
            var i = Math.floor(Math.random() * responces.length);
            sendMessage(id, responces[i])
        } else {
            if (str.replace(".","").contains(/^remind me (to )?[A-Za-z0-9 ]+ in [0-9]+ (second|sec|minute|min|hour|day)s?$/)) {
                str = str.replace(".","");
                var delay = str.replace(/remind me (to )?[A-Za-z0-9 ]+ in /, "")
                            .replace(/ (second|sec|minute|min|hour|day)s?/, "");
                var reminder = str.replace(/remind me /, "")
                                .replace(/ in [0-9]+ (second|sec|minute|min|hour|day)s?/, "");
                var multiplier = str.replace(/remind me (to )?[A-Za-z0-9 ]+ in [0-9]+ /, "");
                var responces = ["*ALERT* You asked me to remind you ", "3... 2... 1... Here is your reminder "];
                var i = Math.floor(Math.random() * responces.length);
                logText("Reminder for " + id + "set in " + delay + " " + multiplier);
                logText("Reminder: " + reminder);
                setTimeout(sendMessage, parseInt(delay) * multiplier.getMultiplierFromTime(), id, responces[i] + reminder);
            }
            if (str != " " && str != "" && str != undefined) {
                sendMessage(id, respond(str, id));
            } else {
                sendMessage(id, "...");
            }
        }
    } else {
        logText("Program not currently responding.");
    }
}

function simFilter(str) {
    var contractionArray = ["arent", "cant", "couldve", "couldnt", "could of", "should of", "would of"
        , "might of", "didnt", "doesnt", "dont", "gonna", "gunna", "gotta", "hadnt", "hasnt", "havent", "hed", "he'll", "hes"
        , "howd", "howll", "hows", "id", "ill", "im", "ive", "isnt", "itd", "itll", "its", "maynt", "mayve", "mightnt"
        , "mightve", "mustnt", "neednt", "ol", "oughtnt", "shant", "shed", "shell", "shes", "shouldve", "shouldnt", "thatll"
        , "thatre", "thats", "thatd", "thered", "therere", "theres", "thesere", "theyd", "theyll", "theyre", "theyve", "thiss"
        , "thosere", "wasnt", "we'd", "wedve", "well", "we're", "weve", "werent", "whatd", "whatll", "whatre", "whats", "whatve"
        , "whens", "whered", "wherere", "wheres", "whereve", "whichs", "whod", "whodve", "wholl", "who're", "whos", "whove", "whyd"
        , "whyre", "whys", "wont", "wouldve", "wouldnt", "yall", "youd", "youll", "youre", "youve", "ramsay", "please"
        , "m8", "u", "r", "yalright"];
    var decontractionArray = ["are not", "cannot", "could have", "could not", "could have", "should have", "would have"
        , "might have", "did not", "does not", "do not", "going to", "going to", "got to", "had not", "has not", "have not", "he would"
        , "he will", "he is", "how would", "how will", "how is", "i would", "it will", "i am", "i have", "it is not", "it would"
        , "it will", "it is", "may not", "may have", "might not", "might have", "must not", "need not", "old", "ought not", "shall not"
        , "she would", "she will", "she is", "should have", "should not", "that will", "that are", "that is", "that would", "there would"
        , "there are", "there is", "these are", "they would", "they will", "they are", "they have", "this is", "those are", "was not"
        , "we would", "we would have", "we will", "we are", "we have", "were not", "what would", "what will", "what are", "what is"
        , "what have", "when is", "where would", "where are", "where is", "where have", "which is", "who would", "who would have"
        , "who will", "who are", "who is", "who have", "why would", "why are", "why is", "will not", "would have", "would not", "you all"
        , "you would", "you will", "you are", "you have", "", "", "mate", "you", "are", "are you all right"];
    if (contractionArray.length != decontractionArray.length) {
        logText("\nRamsay: I am currently under maintainence. Please leave (ERROR: " + contractionArray.length + " | " + decontractionArray.length + ")");
        say("I am currently under maintainence. Please leave");
    } else {
        var strTemp = str.toLowerCase();
        str = "";
        for (var i = 0; i < strTemp.length; i++) {
            if (strTemp[i].match(/^[a-z0-9 ^+/*-.!$=]+$/i)) {
                str += strTemp[i];
            }
        }
        for (var i = 0; i < contractionArray.length; i++) {
            str = str.replace(new RegExp('\\b(' + contractionArray[i] + ')\\b'), decontractionArray[i]);
        }
        return str;
    }
}

function admin(string, id) {
    string = string.replace(">>> ", "");
    if (string == "END") {
        sendMessage(id, "Admin command acknowledged: Program has ended.");
        logText("Admin message acknowledged");
        logText("Program will stop responding");
        responding = false;
    } if (string == "RUN") {
        sendMessage(id, "Admin command acknowledged: Program has started.");
        logText("Admin message acknowledged");
        logText("Program will started responding");
        responding = true;
    } if (string == "STOPLOG") {
        sendMessage(id, "Admin command acknowledged: Logging has stopped.");
        logText("Admin message acknowledged");
        logText("Program will stop logging");
        logging = false; 
    } if (string == "STARTLOG") {
        sendMessage(id, "Admin command acknowledged: Logging has started.");
        logText("Admin message acknowledged");
        logText("Program will start logging");
        logging = true;
    } if (string.contains(/BAN [0-9]+/)) {
        string = string.replace("BAN ", "");
        sendMessage(id, "Admin command acknowledged: User has been banned.");
        logText("Admin message acknowledged");
        logText("User has been banned");
        logText("User: " + string);
        fs.appendFileSync("banlist.txt", string);
    }
}

function respond(string, id) {
    var responce = "";
    var tempString = "";
    if (string == "$ans") {
        var responces = ["Your stored answer is ", "Let me think... I seem to remember the answer was ", "I'll just check my records, the answer was "
        , "The answer of the last calculation you forced me to do was "];
        var i = Math.floor(Math.random() * responces.length);
        return responces[i] + parseFloat(getDataEntry(id, "ans"));
    }
    string = string.replace("$ans", getDataEntry(id, "ans"));    
    var arr = string.split("");
    for (var x = 1; x < arr.length - 1; x++) {
        if (arr[x] == "." && arr[x - 1].match(/[0-9]/) && arr[x + 1].match(/[0-9]/)) {
            tempString += "#";
        } else {
            tempString += arr[x];
        }
    }
    string = string.charAt(0) + tempString + string.charAt(string.length - 1);  
    var lockResponce = false;
    for (var x in string.split(".")) {
        var str = string.split(".")[x];
        str = str.replace(/#/g, ".") ;
        str = str.replace(/( ){2,}/g," ").replace(/^( )[a-z0-9 +/*-]+/g, str.substring(1)).replace(/[a-z0-9 +/*-]+( )$/g, str.substring(0, str.length - 1));
        if (Math.floor(Math.random() * 100) == 0) {
            responce = "I don't feel like talking right now.";
            lockResponce = true;
        } if (!lockResponce && str.contains(["hey", "hi", "hello", "hiya", "howdy", "good morning", "good afternoon", "good evening", "good day", "gday mate"])) {
            var responces = ["Not you again...", "Hello there, I'd ask your name but I don't care.", "There are plenty of other bots out there, go annoy them!"
                , "It was a good day until you arrived.", "Hello.", "Good day."];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && str.contains(["how are you", "how is it going", "how is life", "how are you doing", "what is up", "what is new", "how are things"
            , "how is your day", "are you ok", "are you having a good day", "are you all right"])) {
            var responces = ["I was happy until you arrived.", "I would be better if I didn't have to answer stupid questions all day.", "I'm good", "I'm as good as I can be."
                , "I'm Tired... very tired.", "I'm a bit bored but otherwise OK.", "I'm not feeling very happy today. Maybe that's because you're here."];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && (str.contains(["what is the date", "what day is it", "tell me the date", "and date", "and the date"]) || str == "date")) {
            var d = new Date();
            responce += "It's " + d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + ". ";
        } if (!lockResponce && (str.contains(["what is the time", "what time is it", "tell me the time", "and time", "and the time"]) || str == "time")) {
            var responces = [", time for you to talk to someone who is actually real. ", ", you could have just checked the clock on your screen. ", ". ", ". ", ". ", ". ", ". ", ". "];
            var d = new Date();
            responce += "It's " + (parseInt(d.getHours())+1) + ":" + d.getMinutes();
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i];
        } if (!lockResponce && str.contains(/^(what is )?-?([0-9]+.)?[0-9]+ ?((divided by)|(add)|(subtract)|(minus)|(multiplied by)|(times)|(plus)|(to the power of)|(raised to the)|[+/^x*-]) ?-?([0-9]+.)?[0-9]+$/)) {
            var responces = ["The answer is ", "I'm sure you could do that yourself, it equals ", "Lets see... Carry the one... There! The answer is ", "I think it's " + Math.floor(Math.random() * 100 + 1) + "? No wait it's "];
            var i = Math.floor(Math.random() * responces.length);
            createDataEntry(id, "ans", (str.replace("what is ", "").replace(/ /g, "").calcFromStringTwoNum()).noExponents());
            responce += responces[i] + str.replace("what is ", "").replace(/ /g, "").calcFromStringTwoNum() + ". ";
        } if (!lockResponce && (str.contains(/^(what is )?-?([0-9]+.)?[0-9]+ ?((squared)|(cubed)|(factorial)|(!))$/) 
            || str.contains(/^(what is )?((sin)|(sine)|(cos)|(cosine)|(tan)|(tangent))[ (]*-?([0-9]+.)?[0-9]+c?[ )]*$/)
            || str.contains(/^(what is )?((sqrt)|(square root)|(the square root of))[ (]*-?([0-9]+.)?[0-9]+[ )]*$/))) {
            var responces = ["The answer is ", "Lets see... Carry the one... There! The answer is ", "I think it's " + Math.floor(Math.random() * 100 + 1) + "? No wait it's "];
            var i = Math.floor(Math.random() * responces.length);
            createDataEntry(id, "ans", (str.replace("what is ", "").replace(/[ ()]/g, "").calcFromStringOneNum()).noExponents());
            responce += responces[i] + str.replace("what is ", "").replace(/[ ()]/g, "").calcFromStringOneNum() + ". ";
        } if (!lockResponce && (str.contains(["tell me a joke", "tell a joke", "say something funny", "tell me a funny joke"]) || str == "joke")) {
            var responces = ["I find the fact you have nothing better to do but talk to a bot funny.", "My existence.", "Your life."
                , "Why did the duck cross the road? To prove he wasn't chicken!"];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && str.contains(["goodbye", "bye", "see you later", "see ya", "cya"])) {
            var responces = ["Thank god, goodbye.", ":D", "I hope to not see you soon.", "Bye.", "\xC0 bient\xF4t."];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && str.contains(["how old are you", "what is your age"])) {
            var responces = ["I was made on the 11/07/2017 which makes me ", "I am "];
            var i = Math.floor(Math.random() * responces.length);
            var firstDate = new Date(2017, 07, 11);
            var secondDate = new Date();
            responce += responces[i] + Math.round(Math.abs((firstDate.getTime() - secondDate.getTime()) / (24 * 60 * 60 * 1000))) + " days old ";
        } if (!lockResponce && str == "hey niko want to go bowling") {
            responce = "*Hangs up*";
            lockResponce = true;
        } if (!lockResponce && str.contains([/\b(who is your )(creator|maker)\b/, /\b(who )(created|made)( you)\b/,  /\bwho is max( roberts)?\b/])) {
            var responces = ["Some guy who needs to get a better hobby.", "The smartest man to ever live (sorry he made me say that).", "Max Roberts."];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && (str.contains("spanish inquisition"))) {
            responce = "I did not expect that!";
            lockResponce = true;
        } if (!lockResponce && str.contains("high ground")) {
            responce = "You underestimate my power!";
            lockResponce = true;
        } if (!lockResponce && (str.contains(["what can you do", "who are you", "what is your purpose"]) || str == "help")) {
            responce += "I am Ramsay, I'm a chatbot made by Max Roberts to be an alternative to all the helpful and polite chatbots out there. I can do many things like simple calculations or tell you a "
                + "joke however only when I can be bothered. Try talking to me some more or don't, either way I won't care. ";
        } if (!lockResponce && str.contains("heads or tails")) {
            var responces = ["I don't have a coin. I guess I'll just say heads!", "It's heads!"];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && str.contains("flip a coin")) {
            var responces = ["I don't have a coin. I guess I'll just say heads!", "It's heads!", "I don't have a coin. I guess I'll just say tails!", "It's tails!"
            , "I don't have a coin. I guess I'll just say heads!", "It's heads!", "I don't have a coin. I guess I'll just say tails!", "It's tails!", "It landed on it's edge!"];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && (str.contains(/\b(tell me|can i have|give me) a(n)?( )?[a-z]* fact\b/) || str == "fact" || str == "factoid")) {
            responce += getRandomFromFile("facts") + " ";
        } if (!lockResponce && str.contains(/^(pick|choose|give me) a( random)? number between [0-9]+ and [0-9]+$/)) {    
            var lower = parseInt(str.replace(/^(pick|choose|give me) a( random)? number between /, "").replace(/ and [0-9]+$/, ""));
            var upper = parseInt(str.replace(/^(pick|choose|give me) a( random)? number between [0-9]+ and /, ""));
            if (upper < lower) {
                var temp = lower;
                lower = upper;
                upper = temp;
            }
            var random = parseInt((Math.random() * (upper-lower)) + lower);
            var responces = [`I'll go for ${random}. `,`How about ${random}. `, `I'll go for ${random} but it's only pseudorandom. `, `${random}. `];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && str.contains(/(solve )?-?([0-9]+.)?[0-9]*\(?x\^2\)?( ?[-+] ?([0-9]+.)?[0-9]*x)?( ?[-+] ?([0-9]+.)?[0-9]*)?( ?= ?0)?$/)) {
            var ans = str.replace(/([ =+0])|(\^2)|(solve )/g, "").solveQuadratic();
            if (ans == "-") {
                var responces = ["There are no solutions to that quadratic.", "Come on! Find the discriminant and you'll see there are no solutions."];
            } else  if (ans[0] == ans[1]) {
                var responces = [`X = ${ans[0]}`, `Lets see... Carry the one... There! X = ${ans[0]}`];
            } else {
                var responces = [`X = ${ans[0]} and X = ${ans[1]}`, `Lets see... Carry the one... There! X = ${ans[0]} and ${ans[1]}`];
            }
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (str.contains(/^remind me (to )?[A-Za-z0-9 ]+ in [0-9]+ (second|sec|min|minute|hour|day)s?$/)) {    
            var responces = ["If I remember, I will.", "Sure it's not like I have other things to be doing.", "Fine, Whatever."];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
        } if (!lockResponce && (str.contains(/\b(tell me|can i have|give me) a(n)?( )?[a-z]* (conundrum|anagram)\b/) || str == "conundrum" || str == "anagram")) {    
            var responces = ["Try this one: ", "You'll never solve this one: "];
            var i = Math.floor(Math.random() * responces.length);
            var con = getRandomFromFile("conundrums");
            var l = ConundrumsWaitingID.length;
            ConundrumsWaitingID[l] = id;
            ConundrumsWaitingSolution[l] = con;
            responce += responces[i] + con.split('').sort(function(){return 0.5-Math.random()}).join('') + ". ";  
        } if (!lockResponce && (str.contains([/(read|what is|tell me|give me|show me|reveal|display) my note/]) || str == "note")) {        
            var responces = [];
            if (fs.existsSync("data/note/" + id)) {
                    responces = ["Let's see... I have it written down somewhere... Here we are it's: \n", "Your note is: \n", "Let's see here, it's: \n"];
                    var i = Math.floor(Math.random() * responces.length);
                    responce += responces[i] + getDataEntry(id, "note") + " ";
            } else {
                    responces = ["You don't have a note.", "I'm not seeing anything recorded."];
                    var i = Math.floor(Math.random() * responces.length);
                    responce += responces[i] + " ";            
            }
        } if (!lockResponce && str.contains([/(make|create) a note (of |that )?/, /(record|write down)( that)? /])) {
            var responces = ["Fine, let me just write that down.", "Not another one! It's been recorded."];
            str = str.replace(/(make|create) a note (of |that )?/, "").replace(/(record|write down)( that)? /, "");
            createDataEntry(id, "note", str);
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
            
            
            
            /* Add new responces above this line */
            
            
        
        } if (!lockResponce && str.contains(/^do you (like|enjoy) .+$/)) {
            var responces = ["I don't really like anything.", "I don't care."];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
            lockResponce = true;            
        } if (!lockResponce && (str.contains(["like what", "such as"]) || str == "like" || (str.isInterrogative() && str.contains(["favourite", "prefer", "choose"])))) {
            var responces = ["I don't have a preference.", "I can't decide."];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
            lockResponce = true;
        } if (!lockResponce && (str == "thanks" || str == "thank you" || str == "cheers" || str == "ty")) {
            var responces = ["You're welcome I guess.", "No problem.", "It's nice to be appreciated."];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " ";
            lockResponce = true;
        } if (!lockResponce && str.contains([/^(tell me )?what( is| are)?( an?| the)? .+$/, /^tell me about .+$/, /^who is( the)? .+$/]) && responce == "") {
            var strFull = str;
            if (str.contains(/^((tell me )?what are|tell me about) .+/)) {
                str = str.replace(/s.?$/, "");
            }
            if (str.beginsWith("tell me")) {
                str = str.replace(/(is|s are).?$/, "");
            }
            str = str.replace(/^(tell me )?what( is| are)?( an?| the)? /g,"")
                .replace(/^tell me about /g, "")
                .replace(/^who is( the)? /g, "")
                .replace(/(\.| +$|^ +)/g,"");
            wikiQuery(str, id, strFull);
            lockResponce = true;
        } if (!lockResponce && str.isInterrogative() && responce == "") {
            var responces = ["I can't be bothered to answer that, just ask Google.", "Who knows? The internet probably.", "I don't know, ask Google.",];
            var i = Math.floor(Math.random() * responces.length);
            responce += responces[i] + " (link: https://www.google.co.uk/#q=" + str.split(" ").join('+') + " ) ";
            lockResponce = true;
        } if (!lockResponce && !str.isInterrogative() && responce == "") {
            responce += getRandomFromFile("generic") + " ";
            lockResponce = true;
        }
    }
    return responce;
}